import java.util.Base64;

public class Main {
    public static void main(String[] args) {

        Board board = new Board();
        board.calcNoirsAutorises();
        board.calcBlancsAutorises();

        Player p1 = new Player("W", "Blanc");
        Player p2 = new Player("B", "Noir");
        IA ia1 = new IA("B");

        while (board.nbrTours <= 60) {
            p1.playTurn(board);
            System.out.println("Vous avez joué joué :");
            System.out.println(board.toString());
            //ia1.iaPlayTurnMinmax(board,6);
            ia1.iaPlayTurnAlphaBeta(board,5,0);

            //la valeur de méthode correxpond au choix de score privilégié par l'IA
            //0 est le nombre de pions
            //1 est le nombre de cours possibles
            //2 est le score positionnel
        }



    }
}