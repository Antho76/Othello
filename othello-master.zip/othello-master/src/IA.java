import java.awt.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Objects;

public class IA {

    String color;

    public IA(String c){
        this.color = c;

    }

    public int points(Board board, String couleur, int methode){
        /*
         * Cette fonction est utilisée dans la fonction alphabeta pour retourner le score autre que le seul nombre de points
         * la valeur méthode définit le calcul du score choisi
         * 0 priorise le nombre de pions sur le plateau
         * 1 priorise le nombre de mouvements possibles
         * 2 donne un score selon des valeurs correspondant à chaque cases sur le plateau
         *
         * Toutes ces méthodes retourent un score plus haut si le résusltat est meilleur, permettant de les utiliser facilement*/

        ArrayList<Integer> scorelist =
                new ArrayList<>(Arrays.asList(
                        30,-12,-1,-2,-2,-1,-12,30,
                        -12,-15,-3,-3,-3,-3,-15,-12,
                        -1,-3,-1,-2,-2,-1,-3,-1,
                        -2,-3,-2,1,1,-2,-3,-2,
                        -2,-3,-2,1,1,-2,-3,-2,
                        -1,-3,-1,-2,-2,-1,-3,-1,
                        -12,-15,-3,-3,-3,-3,-15,-12,
                        30,-12,-1,-2,-2,-1,-12,30
                ));

        if (methode == 0){
            if (Objects.equals(couleur, "W")){
                return board.nbBlanc;
            }else{
                return board.nbNoir;
            }
        }else{
            if (methode == 1){
                if (Objects.equals(couleur, "W")){
                    return board.blancsAutorises.size();
                }else{
                    return board.noirsAutorises.size();
                }
            }else{
                int sw = 0;
                int sb = 0;
                for (int i =0; i <board.plateau.size(); i++){
                    if (board.plateau.get(i).equals("W")){
                        sw += scorelist.get(i);
                    }
                    if (board.plateau.get(i).equals("B")){
                        sb += scorelist.get(i);
                    }
                }
                if (Objects.equals(couleur, "W")){
                    return sw;
                }else{
                    return sb;
                }

            }
        }
    }


    public int minMax(Board board, int profondeur, String couleur, ArrayList<Integer> bestMove, int methode){
        /*
        * La fonction minimax est une implémentation de l'algorithme du même nom
        * Elle retourne le score obtenu en fin de parcours, et s'en sert lors de la récursivité
        * Le retour important de la fonction est le bestmove stocké dans une liste, et récupéré en dehors de la fonction
        *
        * si on veut l'utiliser s'inspirer due l'alpha beta pour le corriger*/

        if (board.nbrTours >= 60 || profondeur == 0){
            if (couleur.equals("W")){
                return points(board, "W", methode);
            }else{
                return points(board, "B", methode);
            }
        }
        int bestScore;


        bestScore = -80;
        if (Objects.equals(couleur, "W")){
            for (int coup : board.blancsAutorises){
                ArrayList<String> temp = new ArrayList<>(board.plateau);
                Board b2 = new Board(temp);
                iaPlayTurn(b2,coup,"W", methode);
                bestPos(b2,"B", methode);
                int score = minMax(b2,profondeur-1,couleur,bestMove, methode);

                if (score > bestScore){
                    bestScore = score;
                    bestMove.remove(0);
                    bestMove.add(coup);
                }
            }
        }
        else{
            for (int coup : board.noirsAutorises){
                ArrayList<String> temp = new ArrayList<>(board.plateau);
                Board b3 = new Board(temp);
                iaPlayTurn(b3,coup,"B", methode);
                bestPos(b3,"W", methode);
                int score = minMax(b3,profondeur-1,couleur,bestMove, methode);

                if (score > bestScore){
                    bestScore = score;
                    bestMove.remove(0);
                    bestMove.add(coup);
                }
            }
        }

        return bestScore;

    }
    //TODO Probleme tres problable de l'ia qui veut jouer dans le futur, elle conserve le meilleur coup sur une realite differente future, et la joue dans le present quand c'est plus possible



    public int alphaBeta(Board board, int alpha, int beta, int profondeur, String couleur, ArrayList<Integer> bestMove, int methode, ArrayList<Integer> possibilites, int profbase){
        /*
        * La fonction alphabeta est similaire au minmax plus ahut, mais integre les concepts de coupure alpha et beta
        * elle utilise la methode de calcul de score plus haut
        * elle ressemble globalement à l'algorithme d'un alphabeta pour othello classique*/

        if (board.nbrTours >= 60 || profondeur == 0){
            if (Objects.equals(couleur, "W")){
                return points(board, "W", methode);
            }else{
                return points(board, "B", methode);
            }
        }

        if (couleur.equals("W")){
            for (int coup : board.blancsAutorises){
                ArrayList<String> temp = new ArrayList<>(board.plateau);
                Board b2 = new Board(temp);
                iaPlayTurn(b2,coup,"W", methode);
                bestPos(b2,"B", methode);
                int score = alphaBeta(b2,alpha,beta,profondeur-1,"B",bestMove, methode, possibilites, profbase);

                if (score > alpha ){    //TODO probleme ici, on compare le meilleure score obtenu à celui de la premiere etape, ya rien qui passe
                    alpha = score;
                    if (profondeur == profbase){
                        bestMove.remove(0);
                        //System.out.println("on passe");
                        bestMove.add(coup);
                    }

                    if (alpha >= beta){
                        break;
                    }
                }
            }
            //System.out.println("alpha");
            return alpha;
        }
        else{
            for (int coup : board.noirsAutorises){
                ArrayList<String> temp = new ArrayList<>(board.plateau);
                Board b3 = new Board(temp);
                iaPlayTurn(b3,coup,"B", methode);
                bestPos(b3,"W", methode);
                int score = alphaBeta(b3,alpha,beta,profondeur-1,"W",bestMove,methode, possibilites, profbase);

                if (score < beta){
                    beta = score;
                    if (profondeur == profbase){
                        bestMove.remove(0);
                        //System.out.println("on passe dans l'autre couleur");
                        bestMove.add(coup);
                    }
                    if (alpha >= beta){
                        break;
                    }
                }
            }
            //System.out.println("beta");
            return beta;
        }

    }



    public int bestPos(Board board, String color, int methode){
        /*
        * Fonction qui teste toutes les positions possibles dans la liste autorisée et
        * retourne le score choisi par la methode
        * sert dans les fonctions minmax et alphabeta*/

        int max = -64;
        int pos = -1;

        if (color.equals("W")){
            for (int i : board.blancsAutorises){
                ArrayList<String> temp = new ArrayList<>(board.plateau);
                Board nb = new Board(temp);
                int tttt = iaPlayTurn(nb,i,"W", methode);
                if (tttt > max){
                    max = tttt;
                    pos = i;
                }
            }
        }
        else {
            for (int i : board.noirsAutorises){
                ArrayList<String> temp = new ArrayList<>(board.plateau);
                Board nb = new Board(temp);
                int ttt = iaPlayTurn(nb,i,"B", methode);
                if (ttt > max){
                    max = ttt;
                    pos = i;
                }
            }
        }
        return pos;
    }

    public int iaPlayTurn(Board board,int poschoisie,String couleur, int methode){
        /*
        * Fonction qui joue le tour de l'IA avec la position choisie dans le tableau donné
        * sert à simuler des tours dans les fonctions récursives
        * utilise aussi la méthode definie plus haut*/

        if (couleur.equals("W")){
            for (int cb : board.blancsAutorises){
                board.plateau.set(cb,"/");
            }
        }else{
            for (int cb : board.noirsAutorises){
                board.plateau.set(cb,"/");
            }
        }


        if (couleur.equals("W")) {

                board.nbrTours += 1;
                board.blancsAutorises.remove((Integer) poschoisie);
                board.plateau.set(poschoisie,"W");
                board.update(couleur,poschoisie);
                board.calcNoirsAutorises();

                for(int cc : board.blancsAutorises){
                    board.plateau.set(cc,".");
                }

                return points(board,"W", methode);

        }

        if (couleur.equals("B")) {

                board.nbrTours += 1;
                board.noirsAutorises.remove((Integer) poschoisie);
                board.plateau.set(poschoisie,"B");
                board.update(couleur,poschoisie);
                board.calcBlancsAutorises();

                for(int ca : board.noirsAutorises){
                    board.plateau.set(ca,".");
                }
                return points(board, "B", methode);



        }
        System.out.println("ya eu une erreur dans le tour de l'ia");
        return 0; // cas d'erreur, ne devrait pas apparaitre
    }

    public void iaPlayTurnMinmax(Board board, int profondeur, int methode){
        /*
        * Joue un tour complet de l'IA en utilisant l'algorithme minimax*/

        ArrayList<Integer> pos = new ArrayList<>();
        pos.add(0);
        board.checkPosBoard();
        minMax(board,profondeur,color,pos, methode);
        iaPlayTurn(board,pos.get(0),color, methode);

    }

    public void iaPlayTurnAlphaBeta(Board board, int profondeur, int methode){
        /*
        * Joue un tour complet de l'IA avec l'algorithme alphabeta*/

        ArrayList<Integer> pos = new ArrayList<>();
        pos.add(0);
        board.checkPosBoard();
        ArrayList<Integer> possibilites = new ArrayList<>();
        if (color == "W"){
            possibilites = board.blancsAutorises;
        }
        else{
            possibilites = board.noirsAutorises;
        }
        alphaBeta(board,-1000,1000,profondeur,color,pos, methode, possibilites,profondeur);
        iaPlayTurn(board,pos.get(0),color, methode);
    }
}
