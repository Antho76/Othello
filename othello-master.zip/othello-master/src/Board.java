import java.util.ArrayList;
import java.util.Arrays;

public class Board {
    public ArrayList<String> plateau = new ArrayList<>();
    public int nbrTours;
    public ArrayList<Integer> blancsAutorises = new ArrayList<>();
    public ArrayList<Integer> noirsAutorises = new ArrayList<>();

    public int nbBlanc;

    public int nbNoir;


    public Board() {

        nbrTours = 0;
        for (int i = 0; i < 64; i++) {
            plateau.add(i, ".");
        }

        plateau.set(27, "W");
        plateau.set(28, "B");
        plateau.set(35, "B");
        plateau.set(36, "W");
        nbBlanc = 2;
        nbNoir = 2;

        calcBlancsAutorises();
        calcNoirsAutorises();
    }

    public Board(ArrayList<String> as){
        plateau = as;
        calcBlancsAutorises();
        calcNoirsAutorises();

        for (String s : plateau){
            if (s.equals("W")){
                nbBlanc+=1;
            }
            if (s.equals("B")){
                nbNoir+=1;
            }
        }
    }


    public void calcBlancsAutorises() {
        /*
        * Calcule les positions de jeu autorisées pour le joueur blanc */

        int index = -1;
        ArrayList<Integer> pos = new ArrayList<Integer>(Arrays.asList(-7,-8,-9,-1,1,7,8,9));
        blancsAutorises.clear();

        for (String a : plateau) {
            index += 1;
            if (a.equals("B")) {        //-7,-8,-9,-1,1,7,8,9

                for (Integer i : pos){
                    if(index+i >0 && index+i <64 && plateau.get(index+i).equals(".") && !blancsAutorises.contains(index+i)){

                        if (checkNext("W",index,-i)){
                            blancsAutorises.add(index+i);
                        }
                    }
                }
            }
        }
    }

    public void calcNoirsAutorises() {
        /*
        * Similaire à plus haut pour la couleur noire*/

        int index = -1;
        ArrayList<Integer> pos = new ArrayList<Integer>(Arrays.asList(-7,-8,-9,-1,1,7,8,9));
        noirsAutorises.clear();


        for (String a : plateau) {
            index += 1;
            if (a.equals("W")) {        //-7,-8,-9,-1,1,7,8,9

                for (Integer i : pos){
                    if(index+i >=0 && index+i <64 && plateau.get(index+i).equals(".") && !noirsAutorises.contains(index+i)){

                        if (checkNext("B",index,-i)){
                            noirsAutorises.add(index+i);
                        }
                    }
                }
            }
        }
    }

    public void checkPosBoard(){
        /*
        * evident*/
        calcNoirsAutorises();
        calcBlancsAutorises();
    }

    public Boolean checkNext(String color, int index, int step) {
        int nextIndex = index + step;

        // Vérification des limites du plateau et des sauts de ligne
        if (nextIndex < 0 || nextIndex >= 64 || Math.abs((index % 8) - (nextIndex % 8)) > 1) {
            return false;
        }

        String nextValue = plateau.get(nextIndex);

        if (nextValue.equals(".")) {
            return false; // Case vide : arrêt de la recherche
        }

        if (nextValue.equals(color)) {
            return true; // Trouvé un pion de la même couleur
        }

        // Continue la recherche dans la même direction
        return checkNext(color, nextIndex, step);
    }


    public void update(String c, int index){
        /*met à jour le tableau de jeu apres qu'un pion soit placé et change la couleur de tous le spions capturés*/

        ArrayList<Integer> checkToChange = new ArrayList<>();
        ArrayList<Integer> toChange = new ArrayList<>();
        ArrayList<Integer> pos = new ArrayList<Integer>(Arrays.asList(-7,-8,-9,-1,1,7,8,9));

        for (int e : pos){
            if(updateBoard(c,index,e,toChange)){
                for (int f : toChange){
                    plateau.set(f,c);
                }
                toChange.clear();
            }
        }
        nbBlanc = 0;
        nbNoir = 0;
        for (String s : plateau){
            if (s.equals("W")){
                nbBlanc+=1;
            }
            if (s.equals("B")){
                nbNoir+=1;
            }
        }
    }

    public Boolean updateBoard(String color, int index, int step, ArrayList<Integer> toChange) {
        ArrayList<Integer> tempChange = new ArrayList<>(); // Liste temporaire pour les pions à retourner
        int nextIndex = index + step;

        while (nextIndex >= 0 && nextIndex < 64 && Math.abs((index % 8) - (nextIndex % 8)) <= 1) {
            String current = plateau.get(nextIndex);

            if (current.equals(".")) {
                return false; // Case vide : direction non valide
            }

            if (current.equals(color)) {
                // Direction valide : ajoute les pions à retourner
                toChange.addAll(tempChange);
                return true;
            }

            // Ajoute l'index du pion à retourner
            tempChange.add(nextIndex);

            // Avance dans la direction
            index = nextIndex;
            nextIndex += step;
        }

        return false; // Sortie des limites ou direction invalide
    }


    public Boolean winningCheck() {
        /*Verifie les conditions de victoire de la partie
        */
        if ((nbrTours == 48) || (blancsAutorises.isEmpty() && noirsAutorises.isEmpty())) {
            if (nbBlanc > nbNoir) {
                System.out.println("Les blancs gagnent");
            } else {
                System.out.println("Les noirs gagnent");
            }
            return true;
        } else {return false; }
    }




    public String toString() {
        /*Sert à l'affichage du plateau*/
        String RepereHaut = "   A B C D E F G H";

        String Affichage = "";
        for (int i = 0; i < 8; i++) {
            Affichage= Affichage + (i+1) + " |";
            for (int j = 0; j <8; j++){

                Affichage= Affichage + plateau.get(i*8+j);
                Affichage= Affichage + "|";
            }
            Affichage = Affichage + "\n";
        }
        Affichage = RepereHaut + "\n" + Affichage;
        return Affichage;
    }
}
