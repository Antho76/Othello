import javax.swing.*;
import java.io.Console;
import java.util.ArrayList;
import java.util.Scanner;

public class Player {

    private final String color;
    private final String name;

    public Player(String c, String name){
        this.color = c;
        this.name = name;
    }

    public void playTurn(Board board){

        board.checkPosBoard();

        Scanner scanner = new Scanner(System.in);

        System.out.println("C'est à "+name+" de jouer :");
        System.out.println("En quelle position voulez vous placer votre pion?");

        if (color.equals("W")){
            for (int cb : board.blancsAutorises){
                board.plateau.set(cb,"/");
            }
        }else{
            for (int cb : board.noirsAutorises){
                board.plateau.set(cb,"/");
            }
        }

        System.out.println(board.toString());
        String input = scanner.nextLine();

        String in1 = input.substring(0,1).toLowerCase();
        int ligne = Integer.parseInt(input.substring(1));
        int colonne = -1;

        if (in1.equals("a")){
            colonne = 0;
        }if (in1.equals("b")){
            colonne = 1;
        }if (in1.equals("c")){
            colonne = 2;
        }if (in1.equals("d")){
            colonne = 3;
        }if (in1.equals("e")){
            colonne = 4;
        }if (in1.equals("f")){
            colonne = 5;
        }if (in1.equals("g")){
            colonne = 6;
        }if (in1.equals("h")){
            colonne = 7;
        }

        int poschoisie = ((ligne-1) * 8) + colonne;

        if (color.equals("W")) {
            if (!board.blancsAutorises.contains(poschoisie)) {

                System.out.println("Position invalide");
                playTurn(board);
            } else {

                board.nbrTours += 1;
                board.blancsAutorises.remove((Integer) poschoisie);
                board.plateau.set(poschoisie,"W");
                board.update(color,poschoisie);
                board.calcNoirsAutorises();

                for(int cc : board.blancsAutorises){
                    board.plateau.set(cc,".");
                }

            }
        }

        if (color.equals("B")) {
            if (!board.noirsAutorises.contains(poschoisie)) {

                System.out.println("Position invalide");
                playTurn(board);
            } else {

                board.nbrTours += 1;
                board.noirsAutorises.remove((Integer) poschoisie);
                board.plateau.set(poschoisie,"B");
                board.update(color,poschoisie);
                board.calcBlancsAutorises();

                for(int ca : board.noirsAutorises){
                    board.plateau.set(ca,".");
                }
            }
        }
    }
}
